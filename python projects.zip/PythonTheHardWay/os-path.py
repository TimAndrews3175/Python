#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov  2 10:53:08 2018

@author: tandrews
"""

from os import path
print("The current directory is %s" % path.curdir)